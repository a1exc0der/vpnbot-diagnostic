#!/bin/bash
set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
EXTRACT="/tmp/vpnbot-update-320"
ARCHIVE_DIR="$SCRIPT_DIR"
rm -rf "$EXTRACT"
unzip -q "$SCRIPT_DIR/update.zip" -d "$EXTRACT"
chmod +x "$EXTRACT/update_menu.sh"
export UPDATE_EXTRACT_DIR="$EXTRACT"
bash "$EXTRACT/update_menu.sh"
UPDATE_EXIT=$?
# Очистка после завершения (успешного или нет)
rm -rf "$EXTRACT"
# Удаляем распакованные файлы из текущей директории
cd "$ARCHIVE_DIR" && rm -f run_update.sh update_menu.sh update_bot_to_320.sh update.zip 2>/dev/null || true
# Удаляем архив только если обновление успешно
if [ $UPDATE_EXIT -eq 0 ]; then
    rm -f "$ARCHIVE_DIR/ULTIMA-v3.2.0-Update-Full.zip" 2>/dev/null || true
fi
exit $UPDATE_EXIT
