#!/bin/bash

# 🚀 Ultima 3.2.0 VPN Bot — Меню обновления
# Автор и разработчик проекта: alexcoder
# Версия: 3.2.0

set -e

# Цвета
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

log_info()    { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
log_error()   { echo -e "${RED}[ERROR]${NC} $1"; }
log_step()    { echo -e "${CYAN}🔄 $1${NC}"; }

# Баннер
show_banner(){
    echo -e "${PURPLE}"
    echo "╔══════════════════════════════════════════════════════════════╗"
    echo "║                                                              ║"
    echo "║          🚀 ULTIMA VPN Bot — Меню обновления v3.2.0          ║"
    echo "║                                                              ║"
    echo "║              Автор и разработчик проекта: alexcoder          ║"
    echo "║                                                              ║"
    echo "╚══════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

# Определение корня проекта
detect_project_root(){
    if [ -f "$(pwd)/docker-compose.yml" ] && [ -d "$(pwd)/app" ]; then
        PROJECT_ROOT="$(pwd)"
    elif [ -f "/root/vpnbot-v3/docker-compose.yml" ]; then
        PROJECT_ROOT="/root/vpnbot-v3"
    else
        log_error "Не удалось определить корень проекта"
        exit 1
    fi
}

# Чтение значения из .env
read_env(){
    local key="$1"
    local file="${2:-$PROJECT_ROOT/.env}"
    if [ -f "$file" ]; then
        grep "^${key}=" "$file" 2>/dev/null | cut -d '=' -f2- | tr -d '"' | tr -d "'" | xargs
    fi
}

# Получение текущей версии
get_current_version(){
    local env_file="$PROJECT_ROOT/.env"
    local version
    version="$(read_env BOT_VERSION "$env_file")"
    if [ -z "$version" ]; then
        # Пытаемся определить из кода
        if [ -f "$PROJECT_ROOT/app/core/config.py" ]; then
            version=$(grep -E "BOT_VERSION\s*=" "$PROJECT_ROOT/app/core/config.py" 2>/dev/null | head -1 | sed -E "s/.*['\"]([^'\"]+)['\"].*/\1/" || echo "")
        fi
    fi
    echo "${version:-unknown}"
}

# Проверка версии перед обновлением
check_version_before_update(){
    local current_version
    current_version="$(get_current_version)"
    
    log_info "Текущая версия бота: $current_version"
    
    if [ "$current_version" = "3.2.0" ]; then
        log_success "Версия уже актуальна: 3.2.0"
        log_info "Обновление не требуется, перейдите к следующему шагу"
        return 1
    fi
    
    if [ "$current_version" != "3.1.0" ]; then
        log_error "Для обновления до версии 3.2.0 требуется версия 3.1.0"
        log_error "Текущая версия: $current_version"
        log_info "Пожалуйста, сначала обновите бота до версии 3.1.0"
        return 1
    fi
    
    log_success "Версия проверена: $current_version → 3.2.0"
    return 0
}

# Показать меню
show_menu(){
    echo ""
    echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
    echo -e "${CYAN}                    МЕНЮ ОБНОВЛЕНИЯ${NC}"
    echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
    echo ""
    echo -e "${GREEN}1)${NC} Обновить бота с версии 3.1.0 до 3.2.0"
    echo -e "${GREEN}2)${NC} Установить веб-панель"
    echo -e "${GREEN}3)${NC} Откат к предыдущей версии"
    echo -e "${GREEN}4)${NC} Проверить статус бота"
    echo -e "${GREEN}5)${NC} Просмотр логов"
    echo -e "${YELLOW}0)${NC} Выход"
    echo ""
    echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
    echo ""
}

# Проверка статуса бота
check_bot_status(){
    log_step "Проверка статуса бота"
    
    local current_version
    current_version="$(get_current_version)"
    log_info "Версия бота: $current_version"
    
    if docker compose -f "$PROJECT_ROOT/docker-compose.yml" ps bot 2>/dev/null | grep -q "Up"; then
        log_success "Бот запущен"
    else
        log_warning "Бот не запущен"
    fi
    
    if docker compose -f "$PROJECT_ROOT/docker-compose.yml" ps web-panel 2>/dev/null | grep -q "Up"; then
        log_success "Веб-панель запущена"
    else
        log_info "Веб-панель не установлена"
    fi
    
    echo ""
    read -p "Нажмите Enter для продолжения..."
}

# Просмотр логов
view_logs(){
    log_step "Просмотр логов"
    
    echo ""
    echo -e "${CYAN}Выберите что показать:${NC}"
    echo "1) Логи бота (последние 50 строк)"
    echo "2) Логи веб-панели (последние 50 строк)"
    echo "3) Все логи (последние 30 строк)"
    echo "0) Назад"
    echo ""
    read -p "Выбор: " log_choice
    
    case "$log_choice" in
        1)
            docker compose -f "$PROJECT_ROOT/docker-compose.yml" logs bot --tail=50
            ;;
        2)
            docker compose -f "$PROJECT_ROOT/docker-compose.yml" logs web-panel --tail=50 2>/dev/null || log_warning "Веб-панель не установлена"
            ;;
        3)
            docker compose -f "$PROJECT_ROOT/docker-compose.yml" logs --tail=30
            ;;
        0)
            return 0
            ;;
        *)
            log_error "Неверный выбор"
            ;;
    esac
    
    echo ""
    read -p "Нажмите Enter для продолжения..."
}

# Откат
rollback(){
    log_step "Откат к предыдущей версии"
    
    local backup_root="/root/vpnbot-backups/v3.2.0"
    local latest_link="${backup_root}/LATEST"
    
    if [ ! -d "$backup_root" ]; then
        log_error "Директория бэкапов не найдена: $backup_root"
        log_info "Бэкапы должны создаваться автоматически перед обновлением."
        echo ""
        read -p "Нажмите Enter для продолжения..."
        return 1
    fi
    
    # Собираем список доступных бэкапов
    local backups=()
    local backup_dirs=()
    local index=1
    
    echo ""
    echo -e "${CYAN}Доступные бэкапы:${NC}"
    echo ""
    
    # Ищем все директории с MANIFEST
    while IFS= read -r -d '' backup_dir; do
        if [ -f "$backup_dir/MANIFEST" ]; then
            local backup_time=""
            if [ -f "$backup_dir/MANIFEST" ]; then
                backup_time=$(grep "^BACKUP_TIME=" "$backup_dir/MANIFEST" 2>/dev/null | cut -d '=' -f2 || echo "")
            fi
            
            local dir_name=$(basename "$backup_dir")
            local is_latest=""
            if [ -L "$latest_link" ] && [ "$(readlink -f "$latest_link" 2>/dev/null)" = "$backup_dir" ]; then
                is_latest="${GREEN}[LATEST]${NC} "
            fi
            
            if [ -n "$backup_time" ]; then
                local formatted_time="${backup_time:0:4}-${backup_time:5:2}-${backup_time:8:2} ${backup_time:11:2}:${backup_time:14:2}:${backup_time:17:2}"
                echo -e "${GREEN}$index)${NC} $is_latest$formatted_time ($dir_name)"
            else
                echo -e "${GREEN}$index)${NC} $is_latest$dir_name"
            fi
            
            backups+=("$backup_dir")
            backup_dirs+=("$backup_dir")
            index=$((index + 1))
        fi
    done < <(find "$backup_root" -mindepth 1 -maxdepth 1 -type d -print0 2>/dev/null | sort -z -r)
    
    if [ ${#backups[@]} -eq 0 ]; then
        log_error "Бэкапы не найдены. Откат невозможен."
        log_info "Бэкапы должны создаваться автоматически перед обновлением."
        echo ""
        read -p "Нажмите Enter для продолжения..."
        return 1
    fi
    
    echo ""
    echo -e "${YELLOW}0)${NC} Отмена"
    echo ""
    read -p "Выберите бэкап для восстановления: " choice
    
    if [ -z "$choice" ] || [ "$choice" = "0" ]; then
        log_info "Откат отменен"
        return 0
    fi
    
    if ! [[ "$choice" =~ ^[0-9]+$ ]] || [ "$choice" -lt 1 ] || [ "$choice" -gt ${#backups[@]} ]; then
        log_error "Неверный выбор"
        echo ""
        read -p "Нажмите Enter для продолжения..."
        return 1
    fi
    
    local selected_backup="${backups[$((choice - 1))]}"
    
    if [ -z "$selected_backup" ] || [ ! -d "$selected_backup" ] || [ ! -f "$selected_backup/MANIFEST" ]; then
        log_error "Выбранный бэкап недействителен"
        echo ""
        read -p "Нажмите Enter для продолжения..."
        return 1
    fi
    
    log_warning "ВНИМАНИЕ: Это действие откатит все изменения!"
    log_info "Выбранный бэкап: $(basename "$selected_backup")"
    read -p "Вы уверены? (yes/no): " confirm
    
    if [ "$confirm" != "yes" ]; then
        log_info "Откат отменен"
        return 0
    fi
    
    log_step "Выполнение отката..."
    
    # Восстановление .env и лексиконов
    if [ -d "$selected_backup/_backup" ]; then
        if [ -f "$selected_backup/_backup/.env.old" ]; then
            cp -f "$selected_backup/_backup/.env.old" "$PROJECT_ROOT/.env"
            log_success ".env восстановлен"
        fi
        if [ -f "$selected_backup/_backup/lexicon_ru.py.old" ]; then
            cp -f "$selected_backup/_backup/lexicon_ru.py.old" "$PROJECT_ROOT/app/presentation/lexicon/lexicon_ru.py"
            log_success "Лексикон RU восстановлен"
        fi
        if [ -f "$selected_backup/_backup/lexicon_en.py.old" ]; then
            cp -f "$selected_backup/_backup/lexicon_en.py.old" "$PROJECT_ROOT/app/presentation/lexicon/lexicon_en.py"
            log_success "Лексикон EN восстановлен"
        fi
    fi
    
    # Восстановление проекта из архива
    if [ -f "$selected_backup/bot.tar.gz" ]; then
        cd "$(dirname "$PROJECT_ROOT")" || true
        tar -xzpf "$selected_backup/bot.tar.gz" 2>/dev/null || true
        log_success "Проект восстановлен из архива"
    fi
    
    # Перезапуск контейнеров
    cd "$PROJECT_ROOT" || true
    docker compose restart bot >/dev/null 2>&1 || true
    log_success "Контейнер bot перезапущен"
    
    log_success "Откат выполнен успешно"
    echo ""
    read -p "Нажмите Enter для продолжения..."
}

# Главная функция
main(){
    show_banner
    
    detect_project_root
    log_info "Проект: $PROJECT_ROOT"
    
    # Проверка root прав
    if [ "$EUID" -ne 0 ]; then
        log_error "Скрипт должен быть запущен от root"
        exit 1
    fi
    
    while true; do
        clear
        show_banner
        show_menu
        
        read -p "Выберите действие: " choice
        
        case "$choice" in
            1)
                log_step "Обновление бота с версии 3.1.0 до 3.2.0"
                if check_version_before_update; then
                    # Определяем путь к скрипту обновления
                    local update_script
                    if [ -n "$UPDATE_EXTRACT_DIR" ] && [ -f "$UPDATE_EXTRACT_DIR/update_bot_to_320.sh" ]; then
                        update_script="$UPDATE_EXTRACT_DIR/update_bot_to_320.sh"
                    elif [ -f "$(dirname "$0")/update_bot_to_320.sh" ]; then
                        update_script="$(dirname "$0")/update_bot_to_320.sh"
                    else
                        log_error "Скрипт обновления не найден"
                        echo ""
                        read -p "Нажмите Enter для продолжения..."
                        continue
                    fi
                    bash "$update_script"
                else
                    echo ""
                    read -p "Нажмите Enter для продолжения..."
                fi
                ;;
            2)
                log_step "Установка веб-панели"
                local web_panel_script=""
                
                if [ -n "$UPDATE_EXTRACT_DIR" ] && [ -f "$UPDATE_EXTRACT_DIR/app/scripts/install_web_panel.sh" ]; then
                    web_panel_script="$UPDATE_EXTRACT_DIR/app/scripts/install_web_panel.sh"
                elif [ -f "$PROJECT_ROOT/app/scripts/install_web_panel.sh" ]; then
                    web_panel_script="$PROJECT_ROOT/app/scripts/install_web_panel.sh"
                elif [ -f "/root/vpnbot-v3/app/scripts/install_web_panel.sh" ]; then
                    web_panel_script="/root/vpnbot-v3/app/scripts/install_web_panel.sh"
                elif [ -f "$(dirname "$0")/../install_web_panel.sh" ]; then
                    web_panel_script="$(dirname "$0")/../install_web_panel.sh"
                elif [ -f "$(pwd)/app/scripts/install_web_panel.sh" ]; then
                    web_panel_script="$(pwd)/app/scripts/install_web_panel.sh"
                fi
                
                if [ -n "$web_panel_script" ] && [ -f "$web_panel_script" ]; then
                    bash "$web_panel_script"
                else
                    log_error "Скрипт установки веб-панели не найден"
                    log_info "Ожидаемые пути:"
                    log_info "  - $UPDATE_EXTRACT_DIR/app/scripts/install_web_panel.sh (из архива)"
                    log_info "  - $PROJECT_ROOT/app/scripts/install_web_panel.sh"
                    log_info "  - /root/vpnbot-v3/app/scripts/install_web_panel.sh"
                fi
                echo ""
                read -p "Нажмите Enter для продолжения..."
                ;;
            3)
                rollback
                ;;
            4)
                check_bot_status
                ;;
            5)
                view_logs
                ;;
            0)
                log_info "Выход..."
                exit 0
                ;;
            *)
                log_error "Неверный выбор"
                sleep 2
                ;;
        esac
    done
}

main "$@"

