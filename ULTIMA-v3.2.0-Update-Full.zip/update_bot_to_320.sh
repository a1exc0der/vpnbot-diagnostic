#!/bin/bash

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

CURRENT_STEP=0
TOTAL_STEPS=9

step_start() {
    CURRENT_STEP=$((CURRENT_STEP + 1))
    echo -e "${CYAN}[${CURRENT_STEP}/${TOTAL_STEPS}]${NC} $1..."
}

step_ok() {
    echo -e "${GREEN}✓${NC} $1"
}

step_fail() {
    echo -e "${RED}✗${NC} $1"
    return 1
}

log_info()    { echo -e "  ${BLUE}→${NC} $1"; }
log_success() { echo -e "  ${GREEN}✓${NC} $1"; }
log_warning() { echo -e "  ${YELLOW}⚠${NC} $1"; }
log_error()   { echo -e "  ${RED}✗${NC} $1"; }

abort(){ log_error "$1"; exit 1; }


check_root(){
    if [[ $EUID -ne 0 ]]; then
        log_error "Скрипт должен быть запущен от root"
        echo "Используйте: sudo $0"
        exit 1
    fi
}

PROJECT_ROOT=""
BACKUP_ROOT="/root/vpnbot-backups/v3.2.0"
LATEST_LINK="${BACKUP_ROOT}/LATEST"
GITHUB_REPO="a1exc0der/vpnbot-v3"
GITHUB_BRANCH="Update-3.2.0"
GITHUB_ARCHIVE_URL="https://raw.githubusercontent.com/${GITHUB_REPO}/${GITHUB_BRANCH}/app/scripts/update320/ULTIMA-v3.2.0-Update.zip"
ARCHIVE_PATH=""
TMP_DIR=""

detect_project_root(){
    if [ -d "/root/vpnbot-v3" ] && [ -f "/root/vpnbot-v3/docker-compose.yml" ]; then
        PROJECT_ROOT="/root/vpnbot-v3"
    elif [ -f "$(pwd)/docker-compose.yml" ] && [ -d "$(pwd)/app" ]; then
        PROJECT_ROOT="$(pwd)"
    else
        if command -v docker >/dev/null 2>&1; then
            local compose_file
            compose_file=$(docker compose ls --format json 2>/dev/null | grep -o '"ConfigFile":"[^"]*"' | head -1 | cut -d'"' -f4 || true)
            if [ -n "$compose_file" ]; then
                PROJECT_ROOT="$(dirname "$compose_file")"
            fi
        fi
    fi
    
    if [ -z "$PROJECT_ROOT" ] || [ ! -f "$PROJECT_ROOT/docker-compose.yml" ] || [ ! -d "$PROJECT_ROOT/app" ]; then
        abort "Не удалось определить корень проекта. Убедитесь что вы находитесь в директории проекта или установите бота в /root/vpnbot-v3"
    fi
    
    log_info "Корень проекта: $PROJECT_ROOT"
}

read_env(){
    local key="$1"
    local env_file="$2"
    if [ -f "$env_file" ]; then
        local val
        val="$(grep -E "^${key}=" "$env_file" | tail -n1 | cut -d'=' -f2- | tr -d '"' | tr -d "'" || true)"
        echo "$val"
    else
        echo ""
    fi
}

get_current_version(){
    local env_file="$PROJECT_ROOT/.env"
    local version
    version="$(read_env BOT_VERSION "$env_file")"
    if [ -z "$version" ]; then
        echo "3.0.0"
    else
        echo "$version"
    fi
}

check_version_compatibility(){
    local current_version="$1"
    
    log_info "Текущая версия: $current_version"
    log_info "Целевая версия: 3.2.0"
    
    if [ "$current_version" = "3.2.0" ]; then
        log_warning "Версия уже актуальна: 3.2.0"
        log_info "Обновление не требуется"
        return 1
    fi
    
    if [ "$current_version" != "3.1.0" ]; then
        log_error "Для обновления до версии 3.2.0 требуется версия 3.1.0"
        log_error "Текущая версия: $current_version"
        log_info "Пожалуйста, сначала обновите бота до версии 3.1.0"
        return 1
    fi
    
    log_success "Версия проверена: $current_version → 3.2.0"
    return 0
}

backup_database(){
    local backup_dir="$1"
    local env_file="$PROJECT_ROOT/.env"
    
    local db_user db_name db_container
    db_user="$(read_env DB_USER "$env_file" 2>/dev/null || echo "")"
    db_name="$(read_env DB_NAME "$env_file" 2>/dev/null || echo "")"
    
    if [ -z "$db_user" ] || [ -z "$db_name" ]; then
        return 0
    fi
    
    db_container=$(docker compose -f "$PROJECT_ROOT/docker-compose.yml" ps -q db 2>/dev/null || docker ps --filter "name=db" --format "{{.Names}}" | head -1)
    
    if [ -z "$db_container" ]; then
        return 0
    fi
    
    local backup_file="$backup_dir/database_backup.sql"
    docker exec "$db_container" pg_dump -U "$db_user" -d "$db_name" > "$backup_file" 2>/dev/null || true
    return 0
}

backup_user_data(){
    local backup_dir="$1"
    local backup_path="$backup_dir/_backup"
    mkdir -p "$backup_path" || return 1
    
    if [ -f "$PROJECT_ROOT/.env" ]; then
        cp -f "$PROJECT_ROOT/.env" "$backup_path/.env.old" 2>/dev/null || true
    fi
    
    local lexicon_dir="$PROJECT_ROOT/app/presentation/lexicon"
    if [ -f "$lexicon_dir/lexicon_ru.py" ]; then
        cp -f "$lexicon_dir/lexicon_ru.py" "$backup_path/lexicon_ru.py.old" 2>/dev/null || true
    fi
    
    if [ -f "$lexicon_dir/lexicon_en.py" ]; then
        cp -f "$lexicon_dir/lexicon_en.py" "$backup_path/lexicon_en.py.old" 2>/dev/null || true
    fi
    
    return 0
}

create_backup(){
    local ts
    ts="$(date +%Y%m%d-%H%M%S)"
    local backup_dir="${BACKUP_ROOT}/${ts}"
    mkdir -p "$backup_dir"
    
    backup_user_data "$backup_dir" >/dev/null 2>&1 || true
    backup_database "$backup_dir" >/dev/null 2>&1 || true
    
    ( cd "$(dirname "$PROJECT_ROOT")" && \
      tar -czpf "$backup_dir/bot.tar.gz" "$(basename "$PROJECT_ROOT")" \
        --exclude "$(basename "$BACKUP_ROOT")" 2>/dev/null )
    [ -f "$backup_dir/bot.tar.gz" ] || abort "Не удалось создать архив бэкапа бота"
    
    echo "PROJECT_ROOT=$PROJECT_ROOT" > "$backup_dir/MANIFEST"
    echo "BACKUP_TIME=$ts" >> "$backup_dir/MANIFEST"
    
    ln -sfn "$backup_dir" "$LATEST_LINK"
}

find_archive(){
    if [ -n "$UPDATE_EXTRACT_DIR" ] && [ -d "$UPDATE_EXTRACT_DIR" ]; then
        TMP_DIR="$UPDATE_EXTRACT_DIR"
        return 0
    fi
    
    local script_dir
    script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    
    local search_paths=(
        "$script_dir/ULTIMA-v3.2.0-Update.zip"
        "$script_dir/ULTIMA-v*.zip"
        "/root/ULTIMA-v3.2.0-Update.zip"
        "/root/ULTIMA-v*.zip"
        "$PROJECT_ROOT/ULTIMA-v3.2.0-Update.zip"
        "$PROJECT_ROOT/ULTIMA-v*.zip"
        "$(pwd)/ULTIMA-v3.2.0-Update.zip"
        "$(pwd)/ULTIMA-v*.zip"
    )
    
    for pattern in "${search_paths[@]}"; do
        for path in $pattern; do
            if [ -f "$path" ]; then
                ARCHIVE_PATH="$path"
                return 0
            fi
        done
    done
    
    return 1
}

validate_archive(){
    local archive_path="$1"
    
    if [ ! -f "$archive_path" ]; then
        log_error "Архив не найден: $archive_path"
        return 1
    fi
    
    if ! unzip -t "$archive_path" >/dev/null 2>&1; then
        log_error "Архив поврежден или не является ZIP файлом"
        return 1
    fi
    
    if ! unzip -l "$archive_path" | grep -qE "^[[:space:]]+.*VERSION[[:space:]]*$"; then
        log_error "В архиве отсутствует файл VERSION"
        return 1
    fi
    
    if ! unzip -l "$archive_path" | grep -qE "^[[:space:]]+.*app/core/config.py[[:space:]]*$"; then
        log_error "В архиве отсутствуют основные файлы обновления"
        return 1
    fi
    
    return 0
}

extract_archive(){
    local archive_path="$1"
    local tmp_dir
    tmp_dir=$(mktemp -d)
    
    if unzip -q "$archive_path" -d "$tmp_dir" 2>/dev/null && [ -d "$tmp_dir" ] && [ -f "$tmp_dir/VERSION" ]; then
        echo "$tmp_dir"
        return 0
    else
        rm -rf "$tmp_dir" 2>/dev/null || true
        return 1
    fi
}

get_archive_version(){
    local tmp_dir="$1"
    local version_file="$tmp_dir/VERSION"
    
    if [ ! -f "$version_file" ]; then
        return 1
    fi
    
    local version
    version="$(cat "$version_file" 2>/dev/null | tr -d '[:space:]')"
    
    if [ -z "$version" ]; then
        return 1
    fi
    
    if ! echo "$version" | grep -qE '^[0-9]+\.[0-9]+\.[0-9]+'; then
        return 1
    fi
    
    echo "$version"
    return 0
}

update_env_version(){
    local env_file="$PROJECT_ROOT/.env"
    local new_version="${1:-3.2.0}"
    
    if ! grep -qE "^BOT_VERSION=" "$env_file" 2>/dev/null; then
        echo "BOT_VERSION=$new_version" >> "$env_file"
    else
        sed -i.bak "s/^BOT_VERSION=.*/BOT_VERSION=$new_version/" "$env_file" 2>/dev/null || true
        rm -f "$env_file.bak" 2>/dev/null || true
    fi
    return 0
}

sync_lexicons(){
    local lexicon_sync="${TMP_DIR}/app/scripts/update320/lexicon_sync.py"
    local lexicon_dir="$PROJECT_ROOT/app/presentation/lexicon"
    local backup_dir="$(dirname "$LATEST_LINK")"
    local base_ru="${TMP_DIR}/app/presentation/lexicon/lexicon_ru.py"
    local base_en="${TMP_DIR}/app/presentation/lexicon/lexicon_en.py"
    local user_ru="$lexicon_dir/lexicon_ru.py"
    local user_en="$lexicon_dir/lexicon_en.py"
    
    mkdir -p "$lexicon_dir"
    
    if [ ! -f "$base_ru" ] || [ ! -f "$base_en" ]; then
        return 0
    fi
    
    if [ ! -f "$lexicon_sync" ]; then
        if [ ! -f "$user_ru" ] || [ ! -f "$user_en" ]; then
            cp -f "$base_ru" "$user_ru" 2>/dev/null || true
            cp -f "$base_en" "$user_en" 2>/dev/null || true
        fi
        return 0
    fi
    
    mkdir -p "$PROJECT_ROOT/app/scripts/update320"
    cp -f "$lexicon_sync" "$PROJECT_ROOT/app/scripts/update320/" 2>/dev/null || true
    
    if [ ! -f "$user_ru" ]; then
        cp -f "$base_ru" "$user_ru" 2>/dev/null || true
    fi
    
    if [ ! -f "$user_en" ]; then
        cp -f "$base_en" "$user_en" 2>/dev/null || true
    fi
    
    python3 "$PROJECT_ROOT/app/scripts/update320/lexicon_sync.py" \
        "$base_ru" "$user_ru" "$base_en" "$user_en" "$backup_dir" >/dev/null 2>&1 || return 1
    
    if [ ! -f "$user_ru" ] || [ ! -f "$user_en" ]; then
        return 1
    fi
    
    return 0
}

update_code_files(){
    local files=(
        "app/core/config.py"
        "app/domain/services/vpn_service.py"
        "app/presentation/telegram/handlers/admin/main.py"
        "app/presentation/telegram/handlers/admin/tools.py"
        "app/presentation/telegram/handlers/admin/vpn_management.py"
        "app/presentation/telegram/handlers/admin/commands.py"
        "app/presentation/telegram/handlers/admin/users.py"
        "app/presentation/telegram/handlers/configs.py"
        "app/presentation/telegram/handlers/users.py"
        "app/presentation/telegram/handlers/vpn/user_configs.py"
        "app/presentation/telegram/handlers/vpn.py"
        "app/domain/models/user.py"
        "app/infrastructure/database/connection.py"
        "app/presentation/lexicon/lexicon_manager.py"
        "docker-compose.yml"
        "Dockerfile.web"
        "requirements.txt"
        "app/web/__init__.py"
        "app/web/main.py"
        "app/web/middlewares/__init__.py"
        "app/web/middlewares/auth.py"
        "app/web/routers/__init__.py"
        "app/web/routers/auth.py"
        "app/web/routers/balance.py"
        "app/web/routers/configs.py"
        "app/web/routers/dashboard.py"
        "app/web/routers/landing.py"
        "app/web/routers/profile.py"
        "app/web/routers/referral.py"
        "app/web/routers/statistics.py"
        "app/web/templates/auth.html"
        "app/web/templates/balance.html"
        "app/web/templates/base.html"
        "app/web/templates/config_detail.html"
        "app/web/templates/configs.html"
        "app/web/templates/dashboard.html"
        "app/web/templates/landing.html"
        "app/web/templates/payments.html"
        "app/web/templates/profile.html"
        "app/web/templates/referral.html"
        "app/web/templates/statistics.html"
        "app/web/templates_config.py"
        "app/web/utils.py"
        "app/main.py"
        "app/presentation/telegram/handlers/start.py"
        "app/presentation/telegram/handlers/language.py"
        "app/presentation/telegram/handlers/payment.py"
        "app/presentation/telegram/handlers/settings.py"
        "app/presentation/telegram/handlers/web_access.py"
        "app/presentation/telegram/handlers/__init__.py"
    )
    
    local protected_files=(
        ".env"
        "app/presentation/lexicon/lexicon_ru.py"
        "app/presentation/lexicon/lexicon_en.py"
    )
    
    local updated_count=0
    
    for file in "${files[@]}"; do
        local src="${TMP_DIR}/${file}"
        local dest="${PROJECT_ROOT}/${file}"
        
        local is_protected=false
        for protected in "${protected_files[@]}"; do
            if [ "$file" = "$protected" ]; then
                is_protected=true
                break
            fi
        done
        
        if [ "$is_protected" = true ]; then
            continue
        fi
        
        if [ -f "$src" ]; then
            # Для файлов в корне (docker-compose.yml, Dockerfile.web и т.д.) dirname вернет ".", нужно обработать это
            local dest_dir=$(dirname "$dest")
            if [ "$dest_dir" != "." ] && [ "$dest_dir" != "$PROJECT_ROOT" ]; then
                mkdir -p "$dest_dir"
            fi
            if cp -f "$src" "$dest" 2>/dev/null; then
                updated_count=$((updated_count + 1))
                log_info "  ✓ Обновлен: $file"
            else
                log_warning "  ⚠ Не удалось обновить: $file"
            fi
        else
            log_warning "  ⚠ Файл не найден в архиве: $file"
        fi
    done
    
    mkdir -p "${PROJECT_ROOT}/app/web/static/css"
    mkdir -p "${PROJECT_ROOT}/app/web/static/js"
    if [ -d "${TMP_DIR}/app/web/static" ]; then
        cp -rf "${TMP_DIR}/app/web/static/." "${PROJECT_ROOT}/app/web/static/" 2>/dev/null || true
    fi
    
    [ $updated_count -eq 0 ] && return 1
    return 0
}

restart_containers(){
    cd "$PROJECT_ROOT" || return 1
    
    docker compose stop bot >/dev/null 2>&1 || docker-compose stop bot >/dev/null 2>&1 || true
    sleep 2
    
    if docker compose up -d bot >/dev/null 2>&1 || docker-compose up -d bot >/dev/null 2>&1; then
        sleep 5
        if docker compose ps bot 2>/dev/null | grep -q "Up"; then
            return 0
        fi
    fi
    
    return 1
}

check_bot_health(){
    cd "$PROJECT_ROOT" || return 1
    
    if ! docker compose ps bot 2>/dev/null | grep -q "Up"; then
        log_error "Контейнер bot не запущен"
        return 1
    fi
    
    if docker compose logs --tail 50 bot 2>/dev/null | grep -qiE "(error|exception|traceback|failed)" | head -5 >/dev/null 2>&1; then
        log_warning "Обнаружены ошибки в логах бота"
        docker compose logs --tail 10 bot 2>/dev/null || true
    else
        log_success "Бот работает корректно"
    fi
    
    return 0
}

auto_rollback(){
    local error_message="$1"
    local backup_dir="${2:-}"
    local previous_version="${3:-3.1.0}"
    
    echo ""
    log_error "═══════════════════════════════════════════════════════"
    log_error "ОШИБКА: $error_message"
    log_error "═══════════════════════════════════════════════════════"
    
    log_info "Откат версии в .env на $previous_version..."
    update_env_version "$previous_version" >/dev/null 2>&1 || true
    
    if [ -z "$backup_dir" ]; then
        backup_dir="$(readlink -f "$LATEST_LINK" 2>/dev/null || true)"
    fi
    
    if [ -n "$backup_dir" ] && [ -f "$backup_dir/MANIFEST" ]; then
        log_info "Выполняется откат из бэкапа..."
        
        if [ -d "$backup_dir/_backup" ]; then
            [ -f "$backup_dir/_backup/.env.old" ] && cp -f "$backup_dir/_backup/.env.old" "$PROJECT_ROOT/.env" 2>/dev/null || true
            [ -f "$backup_dir/_backup/lexicon_ru.py.old" ] && cp -f "$backup_dir/_backup/lexicon_ru.py.old" "$PROJECT_ROOT/app/presentation/lexicon/lexicon_ru.py" 2>/dev/null || true
            [ -f "$backup_dir/_backup/lexicon_en.py.old" ] && cp -f "$backup_dir/_backup/lexicon_en.py.old" "$PROJECT_ROOT/app/presentation/lexicon/lexicon_en.py" 2>/dev/null || true
        fi
        
        if [ -f "$backup_dir/bot.tar.gz" ]; then
            cd "$(dirname "$PROJECT_ROOT")" 2>/dev/null || true
            tar -xzpf "$backup_dir/bot.tar.gz" 2>/dev/null || true
        fi
        
        cd "$PROJECT_ROOT" 2>/dev/null || true
        docker compose restart bot >/dev/null 2>&1 || docker-compose restart bot >/dev/null 2>&1 || true
        
        log_success "Откат выполнен. Бэкап: $backup_dir"
    else
        log_error "Бэкап не найден. Откат невозможен."
    fi
    
    exit 1
}

main(){
    local backup_dir=""
    set +e
    
    step_start "Подготовка и валидация"
    check_root || { step_fail "Требуются root права"; exit 1; }
    detect_project_root || { step_fail "Не найден проект"; exit 1; }
    
    if ! command -v docker >/dev/null 2>&1; then
        step_fail "Docker не найден"; exit 1
    fi
    
    if ! docker compose version >/dev/null 2>&1 && ! docker-compose version >/dev/null 2>&1; then
        step_fail "Docker Compose не найден"; exit 1
    fi
    
    local current_version
    current_version="$(get_current_version)"
    local previous_version="$current_version"
    
    if ! check_version_compatibility "$current_version"; then
        exit 0
    fi
    step_ok "Подготовка завершена"
    
    step_start "Создание бэкапа"
    set +e
    create_backup
    local backup_result=$?
    set -e
    if [ $backup_result -ne 0 ]; then
        step_fail "Ошибка создания бэкапа"
        exit 1
    fi
    
    backup_dir="$(readlink -f "$LATEST_LINK" 2>/dev/null || true)"
    
    if [ -z "$backup_dir" ] || [ ! -d "$backup_dir" ]; then
        step_fail "Ошибка создания бэкапа: директория не найдена"
        exit 1
    fi
    
    if [ ! -f "$backup_dir/bot.tar.gz" ]; then
        step_fail "Ошибка создания бэкапа: архив не найден"
        exit 1
    fi
    
    step_ok "Бэкап создан"
    
    step_start "Поиск архива обновления"
    if [ -z "$UPDATE_EXTRACT_DIR" ]; then
        if ! find_archive 2>/dev/null; then
            step_fail "Архив не найден"
            log_error "Поместите архив ULTIMA-v3.2.0-Update.zip в директорию со скриптом или в /root/"
            auto_rollback "Архив не найден" "$backup_dir" "$previous_version"
            exit 1
        fi
        if ! validate_archive "$ARCHIVE_PATH" 2>/dev/null; then
            step_fail "Архив невалиден"
            auto_rollback "Архив невалиден" "$backup_dir" "$previous_version"
            exit 1
        fi
        TMP_DIR="$(extract_archive "$ARCHIVE_PATH" 2>/dev/null)"
        if [ -z "$TMP_DIR" ] || [ ! -d "$TMP_DIR" ]; then
            step_fail "Ошибка распаковки"
            auto_rollback "Ошибка распаковки" "$backup_dir" "$previous_version"
            exit 1
        fi
    else
        if [ ! -d "$UPDATE_EXTRACT_DIR" ]; then
            step_fail "Директория архива не найдена"
            auto_rollback "Директория архива не найдена" "$backup_dir" "$previous_version"
            exit 1
        fi
        TMP_DIR="$UPDATE_EXTRACT_DIR"
    fi
    
    local archive_version
    archive_version="$(get_archive_version "$TMP_DIR" 2>/dev/null)"
    if [ -z "$archive_version" ] || [ "$archive_version" != "3.2.0" ]; then
        step_fail "Неверная версия в архиве: ${archive_version:-не найдена}"
        auto_rollback "Неверная версия в архиве: ${archive_version:-не найдена}" "$backup_dir" "$previous_version"
        exit 1
    fi
    step_ok "Архив загружен"
    
    step_start "Синхронизация лексиконов"
    if ! sync_lexicons >/dev/null 2>&1; then
        step_fail "Ошибка синхронизации лексиконов"
        auto_rollback "Ошибка синхронизации лексиконов" "$backup_dir" "$previous_version"
        exit 1
    fi
    
    local lexicon_dir="$PROJECT_ROOT/app/presentation/lexicon"
    if [ ! -f "$lexicon_dir/lexicon_ru.py" ] || [ ! -f "$lexicon_dir/lexicon_en.py" ]; then
        step_fail "Файлы лексиконов отсутствуют после синхронизации"
        auto_rollback "Файлы лексиконов отсутствуют" "$backup_dir" "$previous_version"
        exit 1
    fi
    
    step_ok "Лексиконы синхронизированы"
    
    step_start "Обновление файлов"
    
    # Явная проверка и копирование критически важных файлов
    log_info "Проверка критически важных файлов..."
    if [ -f "${TMP_DIR}/docker-compose.yml" ]; then
        cp -f "${TMP_DIR}/docker-compose.yml" "${PROJECT_ROOT}/docker-compose.yml" 2>/dev/null && log_success "docker-compose.yml обновлен" || log_warning "Не удалось обновить docker-compose.yml"
    else
        log_warning "docker-compose.yml не найден в архиве"
    fi
    
    if [ -f "${TMP_DIR}/Dockerfile.web" ]; then
        cp -f "${TMP_DIR}/Dockerfile.web" "${PROJECT_ROOT}/Dockerfile.web" 2>/dev/null && log_success "Dockerfile.web обновлен" || log_warning "Не удалось обновить Dockerfile.web"
    else
        log_warning "Dockerfile.web не найден в архиве"
    fi
    
    if [ -f "${TMP_DIR}/requirements.txt" ]; then
        cp -f "${TMP_DIR}/requirements.txt" "${PROJECT_ROOT}/requirements.txt" 2>/dev/null && log_success "requirements.txt обновлен" || log_warning "Не удалось обновить requirements.txt"
    else
        log_warning "requirements.txt не найден в архиве"
    fi
    
    update_code_files >/dev/null 2>&1 || { step_fail "Ошибка обновления кода"; auto_rollback "Ошибка обновления кода" "$backup_dir" "$previous_version"; exit 1; }
    step_ok "Файлы обновлены"
    
    step_start "Перезапуск контейнеров"
    restart_containers >/dev/null 2>&1 || { step_fail "Ошибка перезапуска"; auto_rollback "Ошибка перезапуска контейнеров" "$backup_dir" "$previous_version"; exit 1; }
    step_ok "Контейнеры перезапущены"
    
    step_start "Проверка работоспособности"
    if ! check_bot_health >/dev/null 2>&1; then
        step_fail "Бот не работает"
        auto_rollback "Бот не работает после обновления" "$backup_dir" "$previous_version"
        exit 1
    fi
    step_ok "Бот работает"
    
    step_start "Обновление версии"
    update_env_version "3.2.0" >/dev/null 2>&1 || { step_fail "Ошибка обновления версии"; auto_rollback "Ошибка обновления версии" "$backup_dir" "$previous_version"; exit 1; }
    step_ok "Версия обновлена"
    
    step_start "Перезапуск бота для применения новой версии"
    cd "$PROJECT_ROOT" || { step_fail "Ошибка смены директории"; auto_rollback "Ошибка смены директории" "$backup_dir" "$previous_version"; exit 1; }
    docker compose up -d --force-recreate bot >/dev/null 2>&1 || docker-compose up -d --force-recreate bot >/dev/null 2>&1 || { step_fail "Ошибка перезапуска бота"; auto_rollback "Ошибка перезапуска бота" "$backup_dir" "$previous_version"; exit 1; }
    sleep 5
    if docker compose ps bot 2>/dev/null | grep -q "Up"; then
        step_ok "Бот перезапущен с новой версией"
    else
        step_fail "Бот не запустился после перезапуска"
        auto_rollback "Бот не запустился после перезапуска" "$backup_dir" "$previous_version"
        exit 1
    fi
    
    step_start "Завершение обновления"
    if docker compose -f "$PROJECT_ROOT/docker-compose.yml" ps web-panel 2>/dev/null | grep -q "Up"; then
        local req_file="$PROJECT_ROOT/requirements.txt"
        if [ -f "$req_file" ]; then
            if ! grep -q "^jinja2" "$req_file" 2>/dev/null; then
                echo "jinja2==3.1.3" >> "$req_file"
            fi
            if ! grep -q "^redis" "$req_file" 2>/dev/null; then
                echo "redis==5.0.1" >> "$req_file"
            fi
            if ! grep -q "^fastapi" "$req_file" 2>/dev/null; then
                echo "fastapi==0.110.2" >> "$req_file"
            fi
            if ! grep -q "^uvicorn" "$req_file" 2>/dev/null; then
                echo "uvicorn==0.29.0" >> "$req_file"
            fi
            if ! grep -q "^python-multipart" "$req_file" 2>/dev/null; then
                echo "python-multipart==0.0.9" >> "$req_file"
            fi
        fi
        docker compose -f "$PROJECT_ROOT/docker-compose.yml" build --no-cache web-panel >/dev/null 2>&1 || true
        docker compose -f "$PROJECT_ROOT/docker-compose.yml" up -d web-panel >/dev/null 2>&1 || true
    fi
    
    if [ -n "$TMP_DIR" ] && [ -d "$TMP_DIR" ] && [ "$TMP_DIR" != "$UPDATE_EXTRACT_DIR" ]; then
        rm -rf "$TMP_DIR" 2>/dev/null || true
    fi
    
    step_ok "Обновление завершено успешно"
    
    set -e
    
    echo ""
    echo -e "${GREEN}✓ ОБНОВЛЕНИЕ УСПЕШНО${NC}"
    echo ""
    log_info "Версия бота: ${GREEN}3.2.0${NC}"
    log_info "Бэкап сохранен: $backup_dir"
    log_info "Проект: $PROJECT_ROOT"
    echo ""
    echo -e "${CYAN}Нажмите Enter для возврата в главное меню...${NC}"
    read -r
}

main "$@"
